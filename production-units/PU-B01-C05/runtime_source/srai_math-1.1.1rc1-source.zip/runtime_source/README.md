# SRAI math 1.1.1rc1 — review candidate

Based on the supplied canonical srai_math 1.1.0 sources. The only numerical
change replaces unpivoted QR truncation with an SVD column-space basis in
projection_matrix, correcting zero/dependent leading-column cases.
This is a candidate, not a centrally published or approved runtime release.
Extended SciPy and other optional functionality has not been certified here.
