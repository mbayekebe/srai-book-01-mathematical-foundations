"""Canonical reusable mathematics package for SRAI notebooks."""

from importlib.metadata import PackageNotFoundError, version

try:
    __version__ = version("srai-math")
except PackageNotFoundError:  # source-tree execution before installation
    __version__ = "1.1.1rc1+source"

__all__ = ["__version__"]
